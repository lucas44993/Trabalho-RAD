from screens.login import LoginScreen

if __name__ == "__main__":
    app = LoginScreen()
    app.iniciar() 