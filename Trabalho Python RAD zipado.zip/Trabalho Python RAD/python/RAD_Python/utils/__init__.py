"""
Módulo de utilidades do sistema
""" 